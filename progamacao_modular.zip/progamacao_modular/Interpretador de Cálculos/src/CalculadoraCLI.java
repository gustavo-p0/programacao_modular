import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class CalculadoraCLI {
    private static final Scanner scanner = new Scanner(System.in);
    private static Scanner fileScanner;

    public static void main(String[] args) throws Exception {
        fileScanner = new Scanner(new File("teste.txt"));
        // FileWriter qqr = new FileWriter("gustavo.txt");
        // qqr.close();
        loopCLI();
    }

    private static String readFile(){
        return fileScanner.nextLine();
    }

    /**
     * Read string input given a displayLabel
     * @param displayLabel expression to be show on the screen
     * @return string cli input
     */
    private static String readCommand(String displayLabel){
        System.out.println(displayLabel);
        return scanner.nextLine();
    }

    /*
     * CLI Loop 
     */
    private static void loopCLI(){
        int keepGoing = 1;
        do{
            // String command = readCommand("Digite a expressão no formato <valor> <operador> <valor>:");
            String command = readFile();
            try {
                System.out.println(interpretCommand(command));
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
            
            do {
                // keepGoing = Integer.parseInt(readCommand("Deseja continuar? Digite 1 para (SIM) e 0 para (NAO)"));
                keepGoing = Integer.parseInt(readFile());
            } while (keepGoing != 0 && keepGoing != 1);
            
        }while(keepGoing == 1);
        System.out.println("Obrigado por usar nosso programa");
        closeScanner(fileScanner);
    }

    /**
     * Evaluate an mathematical expression
     * @param operator math operator
     * @param operands in the operation
     * @throws IOException if the operator is unknown
     */
    private static double evals(String operator, double... operands) throws IOException{
        Double result = 0.0;
        double firstOperand = operands[0];
        double secondOperand = operands[1];

        try {
            switch (operator) {
                case "+" ->  result = firstOperand + secondOperand;
                case "-" -> result = firstOperand - secondOperand;
                case "*" -> result = firstOperand * secondOperand;
                case "/" -> result = firstOperand / secondOperand;
                default -> throw new IOException("Operação indisponível");
            }
        } catch (Exception e) {
            System.err.println("Erro inesperado. Fim da execução");
        }
        
        return result;
    }
    /**
     * Interpret an mathematical expression inside the command
     * @param command the mathematical expression
     * @throws IOException if the expression has not sufficient length
     */
    private static double interpretCommand(String command) throws IOException {

        String[] strPieces = command.split(" ");
        if(strPieces.length < 3){
           return 0.0;
        }
        double firstOperand = Double.parseDouble(strPieces[0].replace(",", "."));
        String operator = strPieces[1];
        double secondOperand = Double.parseDouble(strPieces[2].replace(",", "."));
        try {
            return evals(operator, firstOperand, secondOperand);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        
        throw new Error("Erro desconhecido");
    }

    /**
     * Close the scanner
     * @param sc scanner
     */
    private static void closeScanner(Scanner sc){
        sc.close();
    }
}
